local removeableObjects = {}
local makeLuaSprite, makeLuaText, makeAnimatedLuaSprite, close, playMusic, playSound, addAnimationByPrefix, playAnim, objectPlayAnimation, setProperty, getProperty, setObjectCamera, setObjectOrder, setTextString
function close(...) return 0 end

playMusic = close playSound = close addAnimationByPrefix = close
objectPlayAnimation = close setProperty = close getProperty = close
setObjectCamera = close setObjectOrder = close setTextString = close


function makeLuaSprite(tag, ...)
    table.insert(removeableObjects, tag)
    getfenv().makeLuaSprite(tag, ...) -- so it doesnt break
end
function makeLuaText(tag, ...)
    table.insert(removeableObjects, tag)
    getfenv().makeLuaText(tag, ...)
end
function makeAnimatedLuaSprite(tag, ...)
    table.insert(removeableObjects, tag)
    getfenv().makeAnimatedLuaSprite(tag, ...)
end
